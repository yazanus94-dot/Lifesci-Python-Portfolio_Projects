"""Implantable-device battery simulation with PyBaMM.

Life-sciences context: implanted devices (pacemakers, neurostimulators,
biosensors) run on a tiny, near-constant background current plus short
high-current pulses (stimulation / telemetry). Here we use PyBaMM's Single
Particle Model with Electrolyte (SPMe) as a *proxy* Li-ion cell and compare
how pulse amplitude and body vs. room temperature change remaining capacity
and terminal voltage over time.

This is an educational proxy: real pacemakers typically use Li/I2 or Li/CFx
primary cells, and the Chen2020 parameter set is a ~5 Ah cylindrical cell, so mA-range
loads barely move its voltage; the point is the workflow (experiment
protocols, temperature, comparison), not device-accurate lifetimes.
"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pybamm

OUT = Path(__file__).parent / "results"
OUT.mkdir(exist_ok=True)


def run(pulse_current_A: float, temp_C: float, hours: float = 6.0):
    """Baseline drain + one 10-minute pulse every hour (a telemetry/stim burst)."""
    baseline = 0.0005  # A
    one_hour = [
        f"Discharge at {baseline} A for 50 minutes",
        f"Discharge at {pulse_current_A} A for 10 minutes",
    ]
    experiment = pybamm.Experiment(one_hour * int(hours), period="1 minute")
    model = pybamm.lithium_ion.SPMe()
    params = pybamm.ParameterValues("Chen2020")
    params["Ambient temperature [K]"] = 273.15 + temp_C
    params["Initial temperature [K]"] = 273.15 + temp_C
    sim = pybamm.Simulation(model, parameter_values=params, experiment=experiment)
    sol = sim.solve()
    t = sol["Time [h]"].entries
    v = sol["Voltage [V]"].entries
    q = sol["Discharge capacity [A.h]"].entries
    return t, v, q


def main():
    cases = {
        "5 mA pulse, 37 C (body)": (0.005, 37),
        "20 mA pulse, 37 C (body)": (0.020, 37),
        "20 mA pulse, 25 C (room)": (0.020, 25),
    }
    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    rows = []
    for label, (i_pulse, temp) in cases.items():
        t, v, q = run(i_pulse, temp)
        axes[0].plot(t, v, label=label)
        axes[1].plot(t, q * 1000, label=label)
        rows.append((label, v.min(), v[-1], q[-1] * 1000))
    axes[0].set(xlabel="Time (h)", ylabel="Terminal voltage (V)", title="Voltage under pulsed load")
    axes[1].set(xlabel="Time (h)", ylabel="Capacity used (mAh)", title="Cumulative capacity drawn")
    axes[0].legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(OUT / "implant_battery_comparison.png", dpi=150)

    print(f"{'case':28s} {'min V':>7s} {'final V':>8s} {'mAh used':>9s}")
    for label, vmin, vend, mah in rows:
        print(f"{label:28s} {vmin:7.3f} {vend:8.3f} {mah:9.3f}")


if __name__ == "__main__":
    main()
