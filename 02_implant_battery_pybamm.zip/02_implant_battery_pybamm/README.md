# 2. Implantable-device battery under pulsed load (PyBaMM)

Simulates a baseline drain plus hourly 10-minute pulses (stimulation/telemetry burst)
using PyBaMM's SPMe model and the Chen2020 parameter set. Compares 5 mA vs 20 mA pulses
and 37 C (body) vs 25 C.

**Output:** voltage and cumulative capacity curves (`results/implant_battery_comparison.png`)
and a summary table. Capacity drawn matches the hand calculation (e.g. 7.5 mAh for the 5 mA case over 6 h).

**Limitations:** Chen2020 is a ~5 Ah Li-ion cell, a proxy only. Real pacemakers use
Li/I2 or Li/CFx primary cells at microamp loads. At these small currents the temperature
effect is tiny; the value here is the workflow (protocols, parameters, comparison), not lifetime prediction.
Possible extension: scale currents to a smaller cell via parameter changes, add ageing models.
