"""Hydroxyapatite (bone/tooth mineral) structure analysis with pymatgen + ASE.

Builds Ca10(PO4)6(OH)2 from its space group (P6_3/m), analyses composition,
symmetry, Ca-O / P-O coordination, simulates a Cu K-alpha XRD pattern, and
uses ASE for a supercell and a radial distribution function.

Note: the hydroxyl column is ordered here (lowering symmetry to P6_3) and the
hydroxyl hydrogens are omitted; the OH oxygens are kept. Structural data follow Kay et al. (1964) as commonly tabulated.
"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from ase.geometry.analysis import Analysis
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Lattice, Structure
from pymatgen.io.ase import AseAtomsAdaptor
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer

OUT = Path(__file__).parent / "results"
OUT.mkdir(exist_ok=True)


def build_hydroxyapatite() -> Structure:
    lattice = Lattice.hexagonal(a=9.418, c=6.884)
    species = ["Ca", "Ca", "P", "O", "O", "O"]
    coords = [
        [1 / 3, 2 / 3, 0.0015],   # Ca1 (4f)
        [0.2466, 0.9931, 0.25],   # Ca2 (6h)
        [0.3987, 0.3685, 0.25],   # P   (6h)
        [0.3280, 0.4845, 0.25],   # O1  (6h)
        [0.5875, 0.4653, 0.25],   # O2  (6h)
        [0.3433, 0.2568, 0.0702], # O3  (12i)
    ]
    s = Structure.from_spacegroup("P6_3/m", lattice, species, coords)
    # Hydroxyl oxygens sit on the 6_3 axis; in P6_3/m they are disordered
    # (50% occupancy of the 4e site). Here we place one ordered OH column
    # (two O per cell, spaced c/2 apart), which gives Ca10(PO4)6(OH)2 with H omitted.
    for z in (0.1962, 0.6962):
        s.append("O", [0.0, 0.0, z])
    return s


def main():
    s = build_hydroxyapatite()
    print("Formula:", s.composition.reduced_formula, "| atoms in cell:", len(s))
    print("Volume (A^3): %.2f | density (g/cm3): %.3f" % (s.volume, s.density))

    sga = SpacegroupAnalyzer(s, symprec=0.05)
    print("Space group:", sga.get_space_group_symbol(), sga.get_space_group_number())

    n_ca = sum(1 for site in s if site.specie.symbol == "Ca")
    n_p = sum(1 for site in s if site.specie.symbol == "P")
    print("Ca/P ratio: %.3f (stoichiometric HAp = 1.667)" % (n_ca / n_p))

    for el, cutoff in (("P", 1.8), ("Ca", 3.0)):
        d = []
        for site in s:
            if site.specie.symbol == el:
                d += [n.nn_distance for n in s.get_neighbors(site, cutoff) if n.specie.symbol == "O"]
        print(f"{el}-O: n={len(d)}, mean={np.mean(d):.3f} A, min={min(d):.3f}, max={max(d):.3f}")

    xrd = XRDCalculator().get_pattern(s, two_theta_range=(10, 60))
    top = np.argsort(xrd.y)[::-1][:5]
    print("Strongest reflections (2theta, hkl):")
    for i in sorted(top):
        print("  %.2f  %s" % (xrd.x[i], xrd.hkls[i][0]["hkl"]))
    fig, ax = plt.subplots(figsize=(7, 3.5))
    ax.vlines(xrd.x, 0, xrd.y, lw=1)
    ax.set(xlabel="2theta (deg, Cu Ka)", ylabel="Relative intensity", title="Simulated XRD: hydroxyapatite")
    fig.tight_layout(); fig.savefig(OUT / "xrd_hydroxyapatite.png", dpi=150)

    atoms = AseAtomsAdaptor.get_atoms(s).repeat((1, 1, 2))
    rdf, dist = Analysis(atoms).get_rdf(rmax=4.0, nbins=100, return_dists=True)[0]
    fig, ax = plt.subplots(figsize=(7, 3.5))
    ax.plot(dist, rdf)
    ax.set(xlabel="r (A)", ylabel="g(r)", title="RDF, 1x1x2 supercell (ASE)")
    fig.tight_layout(); fig.savefig(OUT / "rdf_supercell.png", dpi=150)

    s.to(filename=str(OUT / "hydroxyapatite.cif"))
    print("Saved CIF + figures to", OUT)


if __name__ == "__main__":
    main()
