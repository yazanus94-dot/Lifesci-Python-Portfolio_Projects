# 1. Hydroxyapatite structure analysis (pymatgen + ASE)

Builds Ca10(PO4)6(OH)2 (the mineral phase of bone and enamel) from its P6_3/m
space-group description and analyses it.

**What it does:** composition and density, symmetry detection, Ca/P ratio,
P-O and Ca-O bond lengths, simulated Cu K-alpha XRD pattern (pymatgen),
supercell + radial distribution function (ASE), CIF export.

**Sanity checks (output):** Ca/P = 1.667 (stoichiometric), P-O mean 1.54 A (typical phosphate),
strongest XRD peaks near 25.9 and 31.8-33.0 degrees 2-theta (known HAp reflections).

**Limitations:** hydroxyl column is ordered and H atoms are omitted, so the symmetry
drops to P6_3 and density is ~3.15 g/cm3 (experimental ~3.16). Structure parameters
come from published tabulations and should be checked against the original paper
before any real use.
