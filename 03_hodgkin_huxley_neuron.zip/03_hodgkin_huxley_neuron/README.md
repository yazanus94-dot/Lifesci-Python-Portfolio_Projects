# 3. Hodgkin-Huxley neuron (SciPy)

Integrates the HH equations with `solve_ivp` (LSODA), builds an f-I curve, estimates
rheobase, and mimics partial tetrodotoxin block by scaling the sodium conductance.

**Results:** rheobase ~3 uA/cm2 (1 uA/cm2 resolution); ~72 Hz at 10 uA/cm2, ~89 Hz at 20 uA/cm2.
Lowering Na+ conductance reduces or abolishes spiking (see `results/hodgkin_huxley.png`).

**Limitations:** single compartment, squid-axon parameters at 6.3 C, spike counting by threshold.
Extensions: temperature scaling (Q10), bifurcation analysis, noise.
