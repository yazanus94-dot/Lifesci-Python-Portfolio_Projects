"""Hodgkin-Huxley neuron: f-I curve, rheobase and TTX block (SciPy).

Simulates the classic squid-axon model (Hodgkin & Huxley, 1952; modern
sign convention, resting potential ~ -65 mV), counts spikes across injected
currents to build a frequency-current (f-I) curve, estimates rheobase, and
shows the effect of partially blocking sodium channels (tetrodotoxin-like).
"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.integrate import solve_ivp
from scipy.signal import find_peaks

OUT = Path(__file__).parent / "results"
OUT.mkdir(exist_ok=True)

C_M, G_NA, G_K, G_L = 1.0, 120.0, 36.0, 0.3     # uF/cm2, mS/cm2
E_NA, E_K, E_L = 50.0, -77.0, -54.387            # mV


def a_m(v): return 0.1 * (v + 40) / (1 - np.exp(-(v + 40) / 10))
def b_m(v): return 4.0 * np.exp(-(v + 65) / 18)
def a_h(v): return 0.07 * np.exp(-(v + 65) / 20)
def b_h(v): return 1.0 / (1 + np.exp(-(v + 35) / 10))
def a_n(v): return 0.01 * (v + 55) / (1 - np.exp(-(v + 55) / 10))
def b_n(v): return 0.125 * np.exp(-(v + 65) / 80)


def rhs(t, y, i_ext, na_scale):
    v, m, h, n = y
    i_na = na_scale * G_NA * m**3 * h * (v - E_NA)
    i_k = G_K * n**4 * (v - E_K)
    i_l = G_L * (v - E_L)
    return [
        (i_ext(t) - i_na - i_k - i_l) / C_M,
        a_m(v) * (1 - m) - b_m(v) * m,
        a_h(v) * (1 - h) - b_h(v) * h,
        a_n(v) * (1 - n) - b_n(v) * n,
    ]


def simulate(i_amp, t_end=200.0, na_scale=1.0, t_on=20.0):
    v0 = -65.0
    y0 = [v0, a_m(v0) / (a_m(v0) + b_m(v0)), a_h(v0) / (a_h(v0) + b_h(v0)),
          a_n(v0) / (a_n(v0) + b_n(v0))]
    i_ext = lambda t: i_amp if t >= t_on else 0.0
    t_eval = np.arange(0, t_end, 0.05)
    sol = solve_ivp(rhs, (0, t_end), y0, t_eval=t_eval, args=(i_ext, na_scale),
                    method="LSODA", rtol=1e-8, atol=1e-10, max_step=0.1)
    return sol.t, sol.y[0]


def spike_count(t, v, t_on=20.0):
    peaks, _ = find_peaks(v, height=0.0, distance=20)   # >=1 ms apart
    return int(np.sum(t[peaks] >= t_on))


def main():
    currents = np.arange(0, 21, 1.0)
    rates = []
    for i in currents:
        t, v = simulate(i)
        rates.append(spike_count(t, v) / 0.18)           # spikes over 180 ms -> Hz
    rates = np.array(rates)
    firing = currents[rates > 0]
    rheobase = firing[0] if len(firing) else np.nan
    print("Rheobase (first firing current, 1 uA/cm2 resolution):", rheobase, "uA/cm2")
    print("Firing rate at 10 uA/cm2: %.1f Hz | at 20 uA/cm2: %.1f Hz" % (rates[10], rates[20]))

    fig, axes = plt.subplots(1, 3, figsize=(14, 3.8))
    for scale, lab in ((1.0, "control"), (0.6, "60% Na$^+$ (partial TTX)"), (0.4, "40% Na$^+$")):
        t, v = simulate(10.0, na_scale=scale)
        axes[0].plot(t, v, label=f"{lab}: {spike_count(t, v)} spikes")
    axes[0].set(xlabel="t (ms)", ylabel="V (mV)", title="Response to 10 uA/cm$^2$"); axes[0].legend(fontsize=8)
    t, v = simulate(10.0)
    axes[1].plot(t, v); axes[1].set(xlim=(15, 60), xlabel="t (ms)", ylabel="V (mV)", title="Spike detail")
    axes[2].plot(currents, rates, "o-"); axes[2].axvline(rheobase, ls="--", c="gray")
    axes[2].set(xlabel="Injected current (uA/cm$^2$)", ylabel="Firing rate (Hz)", title="f-I curve")
    fig.tight_layout(); fig.savefig(OUT / "hodgkin_huxley.png", dpi=150)


if __name__ == "__main__":
    main()
