"""Same oxygen-diffusion problem as oxygen_diffusion_scipy.py, in FEniCSx.

Weak form: find c with c(0)=c0 such that  D * int c' v' dx = - M0 * int v dx
(the natural Neumann condition c'(L)=0 is built in). Compared against the
analytical solution at the end.

NOT RUN in the environment where this repo was generated (dolfinx was not
installable there). Written for dolfinx >= 0.8. Install with:
    conda create -n fenicsx -c conda-forge fenics-dolfinx mpich numpy
Run:  python oxygen_diffusion_fenicsx.py
If your dolfinx version differs, adjust API names and check the printed error.
"""
import numpy as np
import ufl
from dolfinx import fem, mesh
from dolfinx.fem.petsc import LinearProblem
from mpi4py import MPI

D, C0, M0 = 2.0e-5, 4.0e-8, 1.0e-9
L_CRIT = np.sqrt(2 * D * C0 / M0)
L = 0.9 * L_CRIT

domain = mesh.create_interval(MPI.COMM_WORLD, 200, [0.0, L])
V = fem.functionspace(domain, ("Lagrange", 1))

left = mesh.locate_entities_boundary(domain, 0, lambda x: np.isclose(x[0], 0.0))
dofs = fem.locate_dofs_topological(V, 0, left)
bc = fem.dirichletbc(fem.Constant(domain, C0), dofs, V)

c, v = ufl.TrialFunction(V), ufl.TestFunction(V)
a = D * ufl.dot(ufl.grad(c), ufl.grad(v)) * ufl.dx
Lform = -fem.Constant(domain, M0) * v * ufl.dx

problem = LinearProblem(a, Lform, bcs=[bc],
                        petsc_options={"ksp_type": "preonly", "pc_type": "lu"})
sol = problem.solve()

x = V.tabulate_dof_coordinates()[:, 0]
exact = C0 + (M0 / D) * (x**2 / 2 - L * x)
print("L = %.1f um | min c = %.3e | max |FEM - analytic| = %.2e"
      % (L * 1e4, sol.x.array.min(), np.max(np.abs(sol.x.array - exact))))
