"""Oxygen diffusion with uniform consumption in tissue (1D), SciPy solver
verified against the analytical solution.

Problem: D c''(x) = M0 on 0<x<L, c(0)=c0 (capillary wall), c'(L)=0 (symmetry).
Analytical: c(x) = c0 + (M0/D) (x^2/2 - L x). Tissue is anoxic where c<=0,
i.e. the critical thickness is L_crit = sqrt(2 D c0 / M0).
This is the same problem solved with FEniCSx in oxygen_diffusion_fenicsx.py.
"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.sparse import diags
from scipy.sparse.linalg import spsolve

OUT = Path(__file__).parent / "results"
OUT.mkdir(exist_ok=True)

D = 2.0e-5      # cm^2/s, O2 diffusivity in tissue
C0 = 4.0e-8     # mol/cm^3 (~ 40 uM capillary-wall O2)
M0 = 1.0e-9     # mol/(cm^3 s) consumption (illustrative)


def solve_fd(L, n=400):
    h = L / n
    N = n  # unknowns at x_1..x_n; x_0 is Dirichlet
    main = -2.0 * np.ones(N); lower = np.ones(N - 1); upper = np.ones(N - 1)
    # Neumann at x=L via ghost node: c_{n+1} = c_{n-1}
    lower[-1] = 2.0
    A = diags([lower, main, upper], [-1, 0, 1], format="csc") / h**2
    b = (M0 / D) * np.ones(N)
    b[0] -= C0 / h**2
    c = spsolve(A, b)
    return np.concatenate([[C0], c]), np.linspace(0, L, n + 1)


def analytic(x, L):
    return C0 + (M0 / D) * (x**2 / 2 - L * x)


def main():
    l_crit = np.sqrt(2 * D * C0 / M0)
    print("Critical thickness before anoxia: %.1f um" % (l_crit * 1e4))
    fig, ax = plt.subplots(figsize=(6.5, 4))
    for L in (0.5 * l_crit, 0.9 * l_crit, 1.2 * l_crit):
        c, x = solve_fd(L)
        err = np.max(np.abs(c - analytic(x, L)))
        print("L = %6.1f um | min c = %+.3e mol/cm3 | max |FD - analytic| = %.2e" % (L * 1e4, c.min(), err))
        ax.plot(x * 1e4, c * 1e9, label=f"L={L*1e4:.0f} um")
    ax.axhline(0, c="k", lw=0.8)
    ax.set(xlabel="Distance from capillary (um)", ylabel="O2 (nmol/cm$^3$)",
           title="Oxygen profile in tissue (negative = anoxic, unphysical)")
    ax.legend(); fig.tight_layout(); fig.savefig(OUT / "oxygen_profiles.png", dpi=150)


if __name__ == "__main__":
    main()
