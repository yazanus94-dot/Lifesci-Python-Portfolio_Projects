# 4. Oxygen diffusion in tissue (SciPy + FEniCSx)

Steady 1D diffusion with uniform consumption: D c'' = M0, c(0)=c0, c'(L)=0.
Analytical critical thickness L = sqrt(2 D c0 / M0) = 400 um for the chosen
(illustrative) parameters.

- `oxygen_diffusion_scipy.py`: finite-difference solver; **verified** against the
  analytical solution (max error ~1e-20 mol/cm3).
- `oxygen_diffusion_fenicsx.py`: the same problem as a FEniCSx weak form.
  **Not executed** where this repo was generated; written for dolfinx >= 0.8.
  Run it yourself (`conda install -c conda-forge fenics-dolfinx`) and confirm the
  printed error is near machine precision before relying on it.

**Limitations:** zero-order consumption (real tissue uses Michaelis-Menten kinetics, which makes
the problem nonlinear and is a natural next step in FEniCSx with a Newton solver).
